#!/usr/bin/env python3
"""
PhoneTempGuard: jalankan di Termux pada kedua HP.
Contoh:
  python phone_temp.py --device A
  python phone_temp.py --device B
Mode simulasi:
  python phone_temp.py --device A --simulate
  python phone_temp.py --device B --simulate
"""
import argparse
import json
import random
import subprocess
import time
import ssl
from collections import deque
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

BROKER = "broker.hivemq.com"
PORT = 8883
PROJECT_ID = "GANTI_DENGAN_ID_UNIK_KELOMPOK"  # harus sama di semua perangkat
HOT_THRESHOLD_C = 40.0
PUBLISH_EVERY_SEC = 5
WINDOW_SIZE = 3

def topic(suffix):
    return f"phonetempguard/{PROJECT_ID}/{suffix}"

def battery_temperature():
    """Ambil suhu baterai dari Termux:API; hasil None jika tidak tersedia."""
    try:
        result = subprocess.run(
            ["termux-battery-status"],
            capture_output=True, text=True, timeout=5, check=True
        )
        data = json.loads(result.stdout)
        value = data.get("temperature")
        if value is None:
            return None
        value = float(value)
        # Umumnya Termux:API mengembalikan derajat Celsius.
        # Jika perangkat mengembalikan nilai seperti 385, ubah dari persepuluhan.
        if value > 150:
            value = value / 10.0
        if -10 <= value <= 100:
            return value
    except Exception:
        return None
    return None

def notify(title, message):
    try:
        subprocess.run(
            ["termux-notification", "--title", title, "--content", message, "--id", "7401"],
            timeout=4, check=False
        )
        subprocess.run(["termux-vibrate", "-d", "700"], timeout=3, check=False)
    except Exception:
        print("\a", end="", flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", choices=["A", "B"], required=True)
    parser.add_argument("--simulate", action="store_true",
                        help="gunakan suhu simulasi, bukan suhu baterai")
    parser.add_argument("--demo-hot", action="store_true",
                        help="mode simulasi yang sesekali menaikkan suhu untuk demo")
    args = parser.parse_args()
    device = args.device
    samples = deque(maxlen=WINDOW_SIZE)
    last_alert_state = {}
    simulation_temp = 33.0

    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=f"ptg-{PROJECT_ID}-{device}-{random.randint(1000,9999)}"
    )
    client.tls_set(cert_reqs=ssl.CERT_REQUIRED)
    client.reconnect_delay_set(min_delay=1, max_delay=30)

    def on_connect(client, userdata, flags, reason_code, properties):
        print("MQTT terhubung. Kode:", reason_code)
        client.subscribe(topic("telemetry/+"), qos=1)
        client.subscribe(topic("alerts"), qos=1)

    def on_message(client, userdata, msg):
        try:
            data = json.loads(msg.payload.decode("utf-8"))
        except Exception:
            return
        # Setiap HP memantau data HP lain, lalu memberi notifikasi lokal.
        if msg.topic == topic("alerts"):
            if data.get("source_device") != device and data.get("status") == "HOT":
                key = data.get("source_device", "unknown")
                if last_alert_state.get(key) != "HOT":
                    notify("PhoneTempGuard: suhu tinggi", 
                           f"HP {key} terdeteksi panas: {data.get('temperature_c', '?')} °C")
                last_alert_state[key] = "HOT"
            elif msg.topic == topic("alerts") and data.get("status") == "NORMAL":
                last_alert_state[data.get("source_device", "unknown")] = "NORMAL"
            return

        source = data.get("device_id")
        if source and source != device:
            temp = data.get("temperature_c")
            status = data.get("status")
            if status == "HOT" and last_alert_state.get(source) != "HOT":
                notify("PhoneTempGuard: suhu tinggi", f"HP {source} panas: {temp} °C")
            last_alert_state[source] = status

    client.on_connect = on_connect
    client.on_message = on_message
    print(f"Memulai HP {device}. Project ID: {PROJECT_ID}")
    print("Pastikan PROJECT_ID sama di HP A, HP B, dan dashboard.")
    client.connect(BROKER, PORT, keepalive=60)
    client.loop_start()

    try:
        while True:
            if args.simulate:
                if args.demo_hot:
                    # Siklus demonstrasi: normal, lalu panas, lalu normal.
                    phase = int(time.time() // 20) % 3
                    simulation_temp = [33.0, 42.0, 35.0][phase] + random.uniform(-0.4, 0.4)
                else:
                    raw = input("Masukkan suhu simulasi °C (mis. 33 atau 42), atau Enter untuk 33: ").strip()
                    simulation_temp = float(raw) if raw else 33.0
                temperature = simulation_temp
            else:
                temperature = battery_temperature()
                if temperature is None:
                    print("Suhu baterai tidak terbaca. Coba --simulate atau periksa Termux:API.")
                    time.sleep(PUBLISH_EVERY_SEC)
                    continue

            samples.append(temperature)
            avg_temp = sum(samples) / len(samples)
            status = "HOT" if avg_temp >= HOT_THRESHOLD_C else "NORMAL"
            payload = {
                "device_id": device,
                "temperature_c": round(temperature, 2),
                "average_c": round(avg_temp, 2),
                "threshold_c": HOT_THRESHOLD_C,
                "status": status,
                "simulated": bool(args.simulate),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            client.publish(topic(f"telemetry/{device}"), json.dumps(payload), qos=1)
            # Alert dipublikasikan ke topic bersama supaya HP lain menerima peringatan.
            if status == "HOT":
                client.publish(topic("alerts"), json.dumps({
                    "source_device": device,
                    "temperature_c": round(avg_temp, 2),
                    "status": "HOT",
                    "message": f"HP {device} terdeteksi panas",
                    "timestamp": payload["timestamp"]
                }), qos=1)
            print(f"HP {device}: {temperature:.1f}°C | rata-rata {avg_temp:.1f}°C | {status}")
            if args.simulate and not args.demo_hot:
                # Minta nilai baru setiap putaran; input kosong = 33°C
                time.sleep(1)
            else:
                time.sleep(PUBLISH_EVERY_SEC)
    except KeyboardInterrupt:
        print("\nDihentikan.")
    finally:
        client.loop_stop()
        client.disconnect()

if __name__ == "__main__":
    main()
